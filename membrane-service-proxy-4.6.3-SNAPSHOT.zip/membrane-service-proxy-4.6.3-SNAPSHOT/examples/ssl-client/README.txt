SSL for Unsecured Servers

Using the Membrane Service Proxy we can enable clients that do not support SSL to communicate with a SSL secured server.  




RUNNING THE EXAMPLE

In the example we will connect to the following SVN repository without using SSL.
 
 
https://www.google.de/


To run the example execute the following steps:

1. Execute service-proxy.bat

2. Open the URL http://localhost:8080/ in your browser.
