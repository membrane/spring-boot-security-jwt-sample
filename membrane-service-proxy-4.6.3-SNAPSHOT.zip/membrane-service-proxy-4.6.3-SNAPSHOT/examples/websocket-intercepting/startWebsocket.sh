echo please wait
npm install
npm start

