mvn package
java -cp custom-websocket-interceptor-1.0-jar-with-dependencies com.predic8.application.MyApplication