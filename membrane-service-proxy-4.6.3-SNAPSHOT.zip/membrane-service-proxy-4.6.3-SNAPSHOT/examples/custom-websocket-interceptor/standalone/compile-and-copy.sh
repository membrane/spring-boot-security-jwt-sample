mvn package
cp ./target/custom-websocket-interceptor-1.0.jar ../../../lib