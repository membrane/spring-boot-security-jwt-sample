SSL for Unsecured Servers

This example describes how to secure a unsecured Web Service with encryption using SSL.  




RUNNING THE EXAMPLE

In the example we use a public sample service for banking codes. 


http://www.thomas-bayer.com/axis2/services/BLZService?wsdl


To run the example execute the following steps:

1. Go to the examples/ssl-for-unsecured-servers directory.

2. Execute service-proxy.bat

3. Open the URL https://localhost/axis2/services/BLZService?wsdl in your browser.
