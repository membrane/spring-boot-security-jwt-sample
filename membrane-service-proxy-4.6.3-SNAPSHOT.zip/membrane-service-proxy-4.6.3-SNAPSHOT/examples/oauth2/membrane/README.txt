This example shows OAuth2 authorization with OpenID-Connect and OpenID-Discovery. It uses Membrane as authorization server.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/oauth2-code-flow-example.htm