This example shows the OAuth2 password flow. A client requests an access token ( with user credentials ) and the token is verified through a token validator.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/oauth2-password-flow-sample.htm