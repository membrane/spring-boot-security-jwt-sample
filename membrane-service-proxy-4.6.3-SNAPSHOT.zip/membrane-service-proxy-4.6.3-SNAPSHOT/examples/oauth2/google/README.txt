This example shows OAuth2 authorization with help of Google as authorization server.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/oauth2-google.htm