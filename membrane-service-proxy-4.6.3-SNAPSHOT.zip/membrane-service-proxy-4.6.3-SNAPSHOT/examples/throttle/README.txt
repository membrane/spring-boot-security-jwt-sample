THROTTLE INTERCEPTOR

With the ThrottleInterceptor you can delay and limit parallel requests.



RUNNING THE EXAMPLE

In this example we will throttle down access to a web page.

To run the example execute the following steps: 

Execute the following steps:

1. Execute examples/throttle/service-proxy.bat

2. Open the URL http://localhost:2000 in your browser.

3. Notice the delay when you browse.
