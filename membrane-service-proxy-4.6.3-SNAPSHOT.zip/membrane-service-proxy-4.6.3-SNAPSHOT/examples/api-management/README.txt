A simple file based api management approach is in the simple-file-based sub folder.

For an advanced example that has a web console please follow to https://github.com/membrane/api-management